addappid(3070880)
addappid(3070881,0,"7689083b7ce5497c3fe92f58a175d1777d2c19284e940681609557d9d5c940a3")
setManifestid(3070881,"7318690848694068288")



--[[
This file belongs to Ahmeds Bot Discord Server
-----> join discord Server : https://discord.gg/sv6EGxCRnC
]]