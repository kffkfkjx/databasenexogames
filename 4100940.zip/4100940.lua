-- Poppy Playti​​‌‌​​‌‌​‌‌​​‌‌​​‌‌​​‌‌​​​‌‌​‌​​​​‌‌​​‌‌​​‌‌​​​​​​‌‌​‌‌‌​​‌‌​​‌‌​‌‌​​‌​​​‌‌​​‌​‌​​‌‌​​​‌​​‌‌‌​​​​‌‌​​‌​​​‌‌​​​‌​​​‌‌​‌​​​​‌‌​‌‌‌me - Chapter 5
-- AppID 4100940 | Generated on 2026-02-18 17:13 UTC | openlua.cloud
-- Type: DLC

-- Base Game: Poppy Playtime
addappid(1721470)

-- Main Application
addappid(4100940)
