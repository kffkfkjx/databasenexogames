-- 2980270's Lua and Manifest Created by Hubcap Manifest
-- HackHub - Ultimate Hacker Simulator
-- Created: August 06, 2026 at 06:33:04 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2980270, 1, "5938b26512cc59d9be6852e4c97f508a3dd62f3c8280729c408057d8d03c301a") -- HackHub - Ultimate Hacker Simulator
-- MAIN APP DEPOTS
addappid(2980271, 1, "46221cd6ec513106b0e38cefed4ef24f26c78dadb378d172643ec85848cc40d4") -- Depot 2980271
setManifestid(2980271, "6701943406653572332", 1492899117)
addappid(2980272, 1, "c38311bb844e5ff6163a843b12bb3db7f3fd26eb20ac91b24e8b0be933774206") -- Depot 2980272
setManifestid(2980272, "308236721912316614", 1011241244)
-- EMPTY DEPOTS (no content on any branch)
-- addappid(2980273) -- Depot 2980273 (empty depot)