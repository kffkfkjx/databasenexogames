-- 3573430's Lua and Manifest Created by Morrenus
-- Cargo Simulator 25
-- Created: November 09, 2025 at 11:10:48 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3573430) -- Cargo Simulator 25
-- MAIN APP DEPOTS
addappid(3573431, 1, "b52e20b6537b345c0a243cdd553295a6cd467707056827e49e229532aa1eeb19") -- Depot 3573431
setManifestid(3573431, "4372871750801930563", 1414769327)