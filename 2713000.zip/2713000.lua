-- 2713000's Lua and Manifest Created by Hubcap Manifest
-- Resonance: A Plague Tale Legacy
-- Created: August 20, 2026 at 09:36:31 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(2713000) -- Resonance: A Plague Tale Legacy
addtoken(2713000, "17223300556103744127")
-- MAIN APP DEPOTS
addappid(2713001, 1, "7085af990ca726e5a5e97ac1acd51bf4f32ba387d0f3d5edb114720e52b536b4") -- Depot 2713001
setManifestid(2713001, "8465402228324523488", 81349701395)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
-- EMPTY DEPOTS (no content on any branch)
-- addappid(2713002) -- Depot 2713002 (empty depot)