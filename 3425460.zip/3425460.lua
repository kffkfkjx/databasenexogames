-- 3425460's Lua and Manifest Created by Morrenus
-- Console Shop Simulator
-- Created: December 21, 2025 at 18:35:56 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 2
-- Total DLCs: 0
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(3425460, 1, "ac8b5abe48dd2de71930c3f2752463b5702c8033d937c7da451b367f874e6243") -- Console Shop Simulator
-- MAIN APP DEPOTS
addappid(3425461, 1, "c440f018b7251add1a180dc6c2c777e3700d716ed573b41481d0131a5c24f5b1") -- Depot 3425461
setManifestid(3425461, "1367039010112927705", 4515629526)
-- SHARED DEPOTS (from other apps)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)