-- 3896380's Lua and Manifest Created by Morrenus
-- Pizza Restaurant Together
-- Created: December 13, 2025 at 09:53:12 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 1
-- Total DLCs: 1

-- MAIN APPLICATION
addappid(3896380) -- Pizza Restaurant Together
-- MAIN APP DEPOTS
addappid(3896381, 1, "b36bce1f2862fca288ef252df5c05283379b7cd15c43d4697572dbd990ee0ea4") -- Depot 3896381
setManifestid(3896381, "8581323063296569898", 1660391425)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(4170100) -- Pizza Restaurant Together - Vegetable Cutting Machine