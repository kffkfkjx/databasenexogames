-- 4164420's Lua and Manifest Created by Morrenus
-- My Winter Car
-- Created: January 01, 2026 at 18:02:45 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4164420) -- My Winter Car
-- MAIN APP DEPOTS
addappid(4164421, 1, "25786818231b18d0c50cadb12be7d574140d7de03edebbea0fdeb17c8ac49fb7") -- Depot 4164421
setManifestid(4164421, "1234694268958527900", 1085645385)