-- 3525060's Lua and Manifest Created by Morrenus
-- Moving Simulator
-- Created: January 20, 2026 at 20:16:07 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(3525060) -- Moving Simulator
-- MAIN APP DEPOTS
addappid(3525061, 1, "1ae3a9ba78670d0e80f46df07898bff2aeb4129dd5ba4c0c1fce2cac2465531c") -- Depot 3525061
setManifestid(3525061, "5934667600108186087", 6187630211)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)