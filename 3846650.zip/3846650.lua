-- 3846650's Lua and Manifest Created by Morrenus
-- Parking Garage Simulator
-- Created: March 11, 2026 at 18:09:07 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3846650) -- Parking Garage Simulator
-- MAIN APP DEPOTS
addappid(3846651, 1, "13fdae435f8be5ea3ce4b79467a24ec006d96ce730b95793967427c9d97dd98a") -- Depot 3846651
setManifestid(3846651, "2012394997708716096", 9969082225)