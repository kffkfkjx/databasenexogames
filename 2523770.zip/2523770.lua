-- 2523770's Lua and Manifest Created by Hubcap Manifest
-- The Lord of the Rings: War in the North™ - Legacy Edition
-- Created: August 11, 2026 at 12:19:37 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 2
-- Total DLCs: 0
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(2523770) -- The Lord of the Rings: War in the North™ - Legacy Edition
-- MAIN APP DEPOTS
addappid(2523771, 1, "14e7dc6ba004a317cfc4a7095f543092c91234f59c895b096aec1b7fe8111cdd") -- Depot 2523771
setManifestid(2523771, "3512321708538448698", 23229118222)
-- SHARED DEPOTS (from other apps)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)