-- 2824380's Lua and Manifest Created by Hubcap Manifest
-- Exotica 2: Pet Shop Simulator
-- Created: March 15, 2026 at 17:13:39 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(2824380) -- Exotica 2: Pet Shop Simulator
-- MAIN APP DEPOTS
addappid(2824381, 1, "8c97d323d1bf95a6f1568141d8f474c6499e8df543bad47d5c249a49a6129f07") -- Depot 2824381
setManifestid(2824381, "4880730741835567538", 6140703371)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)