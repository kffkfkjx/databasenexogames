-- 4333460's Lua and Manifest Created by Hubcap Manifest
-- The Meter is Running
-- Created: June 05, 2026 at 16:41:11 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4333460) -- The Meter is Running
-- MAIN APP DEPOTS
addappid(4333461, 1, "c0f080c0906475dd254b147f84c9869af47ecfd848e8c8224eba0895ff3aa2fc") -- Depot 4333461
setManifestid(4333461, "1105634932707592187", 728432405)