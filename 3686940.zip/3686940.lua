-- ============================================
--  Credits: K3rnelPan1c (KernelOS / !K3rnalyze)
--  Discord: https://discord.gg/k3rnalyze
--  Website: https://kernelos.org/games
-- ============================================

addappid(3686940)
addappid(3686941,0,"2331c339ed0556fde3815631fb6fa287661c840c34df0766e2e35acf89acff81")
