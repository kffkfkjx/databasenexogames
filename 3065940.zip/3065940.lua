-- ============================================================
-- Descargado desde Walftech  ->  https://walftech.com
-- Generador de Manifest y Lua
-- AppID: 3065940
-- Fecha: 2026-08-21 12:49 UTC
-- ============================================================

--Gamename Gallipoli
addappid(3065940) --Mainappid Gallipoli
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") --Main Windows Depot Gallipoli
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") --Main Windows Depot Gallipoli
addappid(4202450) --Dlcname Gallipoli - Sunburnt Pack
addappid(4202460) --Dlcname Gallipoli - Light Horse Pack
addappid(4202470) --Dlcname Gallipoli - Besieged Pack
addappid(4202490) --Dlcname Gallipoli - Conscript Pack
addappid(4202500) --Dlcname Gallipoli - Ordered to Die Pack
addappid(4584010) --Dlcname Gallipoli - First Expedition
addappid(4584020) --Dlcname Gallipoli - Second Expedition
--Missing Dlcs
--Dlcname Gallipoli Soundtrack