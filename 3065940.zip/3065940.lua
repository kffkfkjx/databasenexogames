-- 3065940's Lua and Manifest Created by Hubcap Manifest
-- Gallipoli
-- Created: August 21, 2026 at 11:07:52 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 7
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(3065940, 1, "744e8d08ac030e739ff4b0c7f412241fb5314e2bc64dd594478ca3171b8143ab") -- Gallipoli
-- MAIN APP DEPOTS
addappid(3065941, 1, "6b014e239ca878274757cee72f94484f4b88eae13426fad855897d6b46e339b1") -- Depot 3065941
setManifestid(3065941, "2367264261538219421", 18998711147)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(4202450) -- Gallipoli - Sunburnt Pack
addappid(4202460) -- Gallipoli - Light Horse Pack
addappid(4202470) -- Gallipoli - Besieged Pack
addappid(4202490) -- Gallipoli - Conscript Pack
addappid(4202500) -- Gallipoli - Ordered to Die Pack
addappid(4584010) -- Gallipoli - First Expedition
addappid(4584020) -- Gallipoli - Second Expedition