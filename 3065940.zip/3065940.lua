-- 3065940's Lua and Manifest Prepared by NexoGameST Tools
-- Gallipoli
-- Created: August 21, 2026 at 16:01:53
-- Powered by NexoGameST Automation
-- Total Depots: 3
-- Total DLCs: 7
-- Shared Depots: 0

addappid(3065940)
addappid(3065941, 1, "2367264261538219421")
setManifestid(3065941,"2367264261538219421")
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") --Main Windows Depot Gallipoli
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") --Main Windows Depot Gallipoli