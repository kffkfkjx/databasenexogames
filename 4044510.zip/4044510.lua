-- 4044510's Lua and Manifest Created by Morrenus
-- Breezy Bakes Simulator
-- Created: February 27, 2026 at 09:13:31 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4044510) -- Breezy Bakes Simulator
-- MAIN APP DEPOTS
addappid(4044511, 1, "ae4d4d1809ff4effc5e9709263d563a73ad181c625aeb848f7bf48932b0224eb") -- Depot 4044511
setManifestid(4044511, "411324745522931633", 4665659054)