-- 3552140's Lua and Manifest Created by Hubcap Manifest
-- Retro Rewind - Video Store Simulator
-- Created: June 24, 2026 at 13:48:21 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(3552140, 1, "7a548aba518c357713b26cf9f8c4df8a0ec93dab267c2f359662ed6656b26bba") -- Retro Rewind - Video Store Simulator
-- MAIN APP DEPOTS
addappid(3552141, 1, "8527bf46fe5454e6c8956a042fb1aee9a9792d7f4c73ebe85ab6924dfcc1c0fe") -- Depot 3552141
setManifestid(3552141, "1240869478989807478", 2240737226)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)