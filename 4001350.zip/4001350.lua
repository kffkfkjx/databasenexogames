-- 4001350's Lua and Manifest Created by Hubcap Manifest
-- Iron Blight
-- Created: August 28, 2026 at 13:52:36 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4001350, 1, "60c48b363aa97236c2aab9504fd3526cf04a409bfc8d4507033e877cac1b990c") -- Iron Blight
-- MAIN APP DEPOTS
addappid(4001351, 1, "c56b7cdaa766f535ace88663def53cc236342daccbb85cbad2701c0ad6bd2371") -- Depot 4001351
setManifestid(4001351, "3887836653248502296", 2702040278)