-- 3533100's Lua and Manifest Created by Hubcap Manifest
-- Wrap House Simulator🌯
-- Created: August 07, 2026 at 15:34:59 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(3533100) -- Wrap House Simulator🌯
-- MAIN APP DEPOTS
addappid(3533101, 1, "165e0dadd51768e263a833318ade634f7f7a76a7fcf9d32356eb4a03e64f0f90") -- Depot 3533101
setManifestid(3533101, "7420537092921148752", 3533385204)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "5753583882400741046", 25674515)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)