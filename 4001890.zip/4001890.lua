-- 4001890's Lua and Manifest Created by Hubcap Manifest
-- How to Fish
-- Created: August 22, 2026 at 11:25:49 EDT
-- Website: https://hubcapmanifest.com/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4001890) -- How to Fish
-- MAIN APP DEPOTS
addappid(4001891, 1, "b5c8ad37740a8db6d370a6934bf203cfaeb3343003e6277ffc96c63f4df2b7ca") -- Depot 4001891
setManifestid(4001891, "4842956112369201488", 642156977)