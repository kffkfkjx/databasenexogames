-- 3393240's Lua and Manifest Created by Morrenus
-- Banker Simulator
-- Created: November 18, 2025 at 16:59:25 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 3
-- Total DLCs: 1
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(3393240) -- Banker Simulator
-- MAIN APP DEPOTS
addappid(3393241, 1, "e7777dcbe56e62de2f413ac181261293609289fbbb8f749ca35f23e5590a437f") -- Depot 3393241
setManifestid(3393241, "6315731893607889610", 6084231314)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(4040350) -- Banker Simulator - Gold Pack